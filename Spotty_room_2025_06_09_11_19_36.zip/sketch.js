function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}let arvores = [];
let lixos = [];
let pontuacao = 0;
let recorde = 0;
let alvo = 10;
let numLixos = 5;
let vidas = 3;
let jogoAcabou = false;

function setup() {
  createCanvas(600, 400);
  textSize(20);
  gerarLixos();
}

function draw() {
  // Fundo (céu)
  background(135, 206, 235);

  // Chão
  fill(100, 200, 100);
  rect(0, height * 0.75, width, height * 0.25);

  // Grama
  drawGrama();

  if (!jogoAcabou) {
    // Lixos em movimento
    for (let lixo of lixos) {
      lixo.x += random(-1, 1);
      lixo.y += random(-0.5, 0.5);
      desenharLixo(lixo.x, lixo.y);
    }

    // Árvores plantadas
    for (let arvore of arvores) {
      desenharArvore(arvore.x, arvore.y);
    }

    // HUD
    fill(0);
    text("Pontuação: " + pontuacao, 10, 30);
    text("Recorde: " + recorde, 10, 60);
    text("Vidas: " + vidas, 10, 90);

    // Verifica fim do jogo
    if (pontuacao >= alvo) {
      jogoAcabou = true;
      recorde = max(recorde, pontuacao);
    }
    if (vidas <= 0) {
      jogoAcabou = true;
    }

  } else {
    // Tela final
    fill(0);
    textAlign(CENTER);
    textSize(28);
    if (pontuacao >= alvo) {
      text("🌳 Parabéns! Você venceu!", width / 2, height / 2 - 20);
    } else {
      text("☹️ Fim de jogo. Você perdeu!", width / 2, height / 2 - 20);
    }
    textSize(18);
    text("Clique para reiniciar", width / 2, height / 2 + 20);
  }
}

function mousePressed() {
  if (jogoAcabou) {
    reiniciarJogo();
    return;
  }

  if (mouseY > height * 0.75 && pontuacao < alvo) {
    let clicouEmLixo = false;

    for (let i = lixos.length - 1; i >= 0; i--) {
      let lixo = lixos[i];
      if (dist(mouseX, mouseY, lixo.x, lixo.y) < 15) {
        lixos.splice(i, 1);
        vidas--;
        clicouEmLixo = true;
        break;
      }
    }

    if (!clicouEmLixo) {
      arvores.push({ x: mouseX, y: mouseY });
      pontuacao++;
    }
  }
}

function desenharArvore(x, y) {
  fill(139, 69, 19);
  rect(x - 5, y - 30, 10, 30);
  fill(34, 139, 34);
  ellipse(x, y - 40, 40, 40);
}

function desenharLixo(x, y) {
  fill(80);
  rect(x - 10, y - 10, 20, 20);
  fill(255);
  textSize(12);
  textAlign(CENTER, CENTER);
  text("🗑️", x, y);
}

function drawGrama() {
  stroke(34, 139, 34);
  for (let i = 0; i < width; i += 10) {
    let x = i;
    let y1 = height * 0.75;
    let y2 = y1 - random(5, 15);
    line(x, y1, x, y2);
  }
  noStroke();
}

function gerarLixos() {
  lixos = [];
  for (let i = 0; i < numLixos; i++) {
    let x = random(20, width - 20);
    let y = random(height * 0.75 + 10, height - 20);
    lixos.push({ x, y });
  }
}

function reiniciarJogo() {
  arvores = [];
  pontuacao = 0;
  vidas = 3;
  jogoAcabou = false;
  gerarLixos();
}
